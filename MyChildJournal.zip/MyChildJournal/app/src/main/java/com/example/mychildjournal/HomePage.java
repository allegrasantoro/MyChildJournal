package com.example.mychildjournal;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.Navigation;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;
import com.google.android.material.navigation.NavigationBarView;

import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomePage#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomePage extends Fragment implements DatePickerDialog.OnDateSetListener, View.OnClickListener {

    //get required views
    ImageView calendarIcon;
    TextView mondayDate;
    TextView tuesdayDate;
    TextView wednesdayDate;
    TextView thursdayDate;
    TextView fridayDate;
    TextView saturdayDate;
    TextView sundayDate;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomePage() {
        // Required empty public constructor
    }

    public static HomePage newInstance(String param1, String param2) {
        HomePage fragment = new HomePage();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home_page, container, false);

        //add listener to trigger date picker dialogue
        calendarIcon = v.findViewById(R.id.calendarIconImage);
        calendarIcon.setClickable(true);
        calendarIcon.setOnClickListener(this);

        //retrieve TextViews where days of the weeks will be displayed
        mondayDate = v.findViewById(R.id.mondayDate);
        tuesdayDate = v.findViewById(R.id.tuesdayDate);
        wednesdayDate = v.findViewById(R.id.wednesdayDate);
        thursdayDate = v.findViewById(R.id.thursdayDate);
        fridayDate = v.findViewById(R.id.fridayDate);
        saturdayDate = v.findViewById(R.id.saturdayDate);
        sundayDate = v.findViewById(R.id.sundayDate);

        //Set default date on load to current date
        DateFormat dateFormatCurrentDate = new SimpleDateFormat("ddd");
        DateFormat dateFormatCurrentWeekday = new SimpleDateFormat("EE");
        Date date = new Date();
        String currentDateString = dateFormatCurrentDate.format(date);
        String currentWeekDay = dateFormatCurrentWeekday.format(date);
        currentDateString= currentDateString.replaceAll("0", "");
        int currentDate = Integer.parseInt(currentDateString);

        populateWeek(v, currentDate, currentWeekDay);

        //Listen to check if the user wants to navigate through tabs using the navbar
        BottomNavigationView navBar = v.findViewById(R.id.navBarHomePage);
        navBar.getMenu().findItem(R.id.homeNav).setChecked(true);
        navBar.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    item.setChecked(true);
                    switch (item.getItemId()) {
                        case R.id.homeNav:
                            return true;
                        case R.id.milestonesNav:
                            Navigation.findNavController(v).navigate(R.id.action_homePage_to_milestones);
                            return true;
                        case R.id.insightsNav:
                            Navigation.findNavController(v).navigate(R.id.action_homePage_to_insights3);
                            return true;
                        case R.id.settingsNav:
                            Navigation.findNavController(v).navigate(R.id.action_homePage_to_settings);
                            return true;
                        default: return true;
                    }
            }
        });

        return v;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.calendarIconImage){
            showDatePickerDialog(v);
        }
        else{
            Log.d("navigation", "onClick() method is called but the view's id does not match the listener components");
        }
    }

    private void showDatePickerDialog(View v){
        DatePickerDialog birthdatePickerDialog = new DatePickerDialog(
                v.getContext(),
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        birthdatePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        DateFormat dateFormatCurrentWeekday = new SimpleDateFormat("EE");
        Date date = new Date(year, month, dayOfMonth-1);
        String dayOfWeek = dateFormatCurrentWeekday.format(date);
        Log.d("onDateSetdayOfWeek", dayOfWeek);
        populateWeek(view , dayOfMonth, dayOfWeek);
    }

    public void populateWeek(View v, int dayOfMonth, String dayOfWeek){
        int[] weekDates = getDaysArray(dayOfMonth, dayOfWeek);
        TextView[] weekDatesTextViewsArray = {mondayDate, tuesdayDate, wednesdayDate, thursdayDate, fridayDate, saturdayDate, sundayDate};
        for (int i = 0; i < 7; i ++){
            weekDatesTextViewsArray[i].setText(Integer.toString(weekDates[i]));

            if (weekDates[i] == dayOfMonth){
                weekDatesTextViewsArray[i].setBackground(ContextCompat.getDrawable(v.getContext(), R.drawable.circle_shape_light_selected));
                weekDatesTextViewsArray[i].setTextColor(Color.parseColor("#f3f3f3ff"));
            }
            else{
                weekDatesTextViewsArray[i].setBackground(ContextCompat.getDrawable(v.getContext(), R.drawable.circle_shape_light_notselected));
                weekDatesTextViewsArray[i].setTextColor(Color.parseColor("#666666"));
            }
        }
    }

    public int[] getDaysArray(int dayOfMonth, String dayOfWeek){
        int[] weekDates = new int[7];
        int selectedWeekDayInt = 0;

        //assigns a numerical value to each day corresponding to their position in the weekdaysTextContainerLinearLayout
        switch(dayOfWeek) {
            case "Mon":
            case "Monday":
                selectedWeekDayInt = 0;
                break;
            case "Tue":
            case "Tuesday":
                selectedWeekDayInt = 1;
                break;
            case "Wed":
            case "Wednesday":
                selectedWeekDayInt = 2;
                break;
            case "Thu":
            case "Thursday":
                selectedWeekDayInt = 3;
                break;
            case "Fri":
            case "Friday":
                selectedWeekDayInt = 4;
                break;
            case "Sat":
            case "Saturday":
                selectedWeekDayInt = 5;
                break;
            case "Sun":
            case "Sunday":
                selectedWeekDayInt = 6;
                break;
            default:
                Log.e("dayOfWeek", "dayOfWeek not recognised");
        }

        //add all days of the selected week to an array
        for (int i = 0; i < 7; i ++){
            weekDates[i] = dayOfMonth + (i-selectedWeekDayInt);
        }

        return weekDates;
    }

}