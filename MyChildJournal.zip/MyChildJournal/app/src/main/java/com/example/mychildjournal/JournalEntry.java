package com.example.mychildjournal;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link JournalEntry#newInstance} factory method to
 * create an instance of this fragment.
 */
public class JournalEntry extends Fragment implements View.OnClickListener {

    ListView mealsListView;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public JournalEntry() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment JournalEntry.
     */
    // TODO: Rename and change types and number of parameters
    public static JournalEntry newInstance(String param1, String param2) {
        JournalEntry fragment = new JournalEntry();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_journal_entry, container, false);

        mealsListView = v.findViewById(R.id.mealsListView);

        ArrayList<String> savedMeals = new ArrayList<>();

        savedMeals.add("Carrot baby food and milk");

        ArrayAdapter savedMealsArrayAdapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, savedMeals);

        mealsListView.setAdapter(savedMealsArrayAdapter);

        Button addChildButton = v.findViewById(R.id.submitButton);
        addChildButton.setOnClickListener(this);

        ImageView backArrow = v.findViewById(R.id.backArrowImage);
        backArrow.setOnClickListener(this);

        Button addMealButton = v.findViewById(R.id.addNewMealButton);
        addMealButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.submitButton){
            //add code to save data and load right fragment
            Navigation.findNavController(v).navigate(R.id.action_journalEntry_to_homePage);
        }
        else if(v.getId() == R.id.backArrowImage){
            Navigation.findNavController(v).navigate(R.id.action_journalEntry_to_homePage);
        }
        else if (v.getId() == R.id.addNewMealButton){
            Navigation.findNavController(v).navigate(R.id.action_journalEntry_to_addAMeal);
        }
        else{
            Log.d("navigation", "onClick() method is called but the view's id does not match the listener components");
        }
    }
}