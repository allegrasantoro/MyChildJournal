package com.example.mychildjournal;

import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddBirthdate#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddBirthdate extends Fragment implements DatePickerDialog.OnDateSetListener, View.OnClickListener {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    TextInputEditText  editText;

    public AddBirthdate() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AddBirthdate.
     */
    // TODO: Rename and change types and number of parameters
    public static AddBirthdate newInstance(String param1, String param2) {
        AddBirthdate fragment = new AddBirthdate();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add_birthdate, container, false);

        editText = v.findViewById(R.id.birthdate_text_input_edit_text);
        editText.setClickable(true);
        editText.setOnClickListener(this);

        Button nextPageButton = v.findViewById(R.id.addNewMealButton);
        nextPageButton.setOnClickListener(this);

        return v;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.addNewMealButton){
            Navigation.findNavController(v).navigate(R.id.action_addBirthdate_to_extraInfo);
        }
        else if (v.getId() == R.id.birthdate_text_input_edit_text){
            showDatePickerDialog(v);
        }
        else{
            Log.d("navigation", "onClick() method is called but the view's id does not match the listener components");
        }

    }

    private void showDatePickerDialog(View v){
        DatePickerDialog birthdatePickerDialog = new DatePickerDialog(
                v.getContext(),
                this,
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        birthdatePickerDialog.show();
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String date = dayOfMonth + "/" + (month + 1) + "/" + year;

        editText.setText(date);
    }
}